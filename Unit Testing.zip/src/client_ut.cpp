#include<cppunit/config/SourcePrefix.h>
#include<string>
#include<algorithm>
#include"sock.h"

CPPUNIT_TEST_SUITE_REGISTRATION( Operator );

void Operator::setUp()
{
	username="sravani";
	password="srav@123";
}
void Operator::getPassword_UT_sunny(){
	string password="srav@123";
	string password2=getPassword();

	CPPUNIT_ASSERT_EQUAL(password, password2);
}
void Operator::getPassword_UT_rainy(){
	string password="345";
	string password2=getPassword();

	CPPUNIT_ASSERT_EQUAL(password,password2);
}
void Operator::getUsername_UT_sunny(){
	std::string Name="sravani";
	std::string Name2=getUsername();

	CPPUNIT_ASSERT_EQUAL(Name, Name2);
}
void Operator::getUsername_UT_rainy(){
	std::string Name="abcd";
	std::string Name2=getUsername();

	CPPUNIT_ASSERT_EQUAL(Name, Name2);
}

