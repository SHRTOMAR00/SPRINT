#pragma once

#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<vector>
#include<algorithm>
#include<cppunit/extensions/HelperMacros.h>

using namespace std;

class Operator: public CPPUNIT_NS::TestFixture
{
	CPPUNIT_TEST_SUITE( Operator );
	CPPUNIT_TEST( getUsername_UT_sunny);
	CPPUNIT_TEST( getPassword_UT_rainy );
	CPPUNIT_TEST(getUsername_UT_rainy);
	CPPUNIT_TEST(getPassword_UT_sunny);
	CPPUNIT_TEST_SUITE_END();

	protected:
		string username;
		string password;
		
	public:
		void setUp();
		void setValues(string uname, string pwd){
			string username=uname;
			string password=pwd;}
		string getPassword(){return password;}
		string getUsername(){return username;}

	protected:

		void getPassword_UT_sunny();
		void getPassword_UT_rainy();
		void getUsername_UT_sunny();
		void getUsername_UT_rainy();
};
