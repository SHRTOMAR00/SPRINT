(Project Name: Call details Record- Inter operator settlement)

Client and Server connection is established using TCP protocol.Client have to send a
request to server to get CDR file which is stored in directory and store the processed
data in STL container. Unique number identifying a subscription in a mobile network
maximum length of MSISDN to 7 digits.
Inter Operator Settlement contains information about “Outgoing choice calls
duration to a subscriber within and outside the mobile operator. As well as it contains
information “Incoming voice calls duration”. It contains “SMS message in both
outgoing (MO) and incoming (MT) “sent both within and outside the mobile
operator. IOS can download and upload MB if call type is GPRS.
