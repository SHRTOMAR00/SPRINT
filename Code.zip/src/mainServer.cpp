#include <sock.h>

int main(int argc, char *argv[])
{
	OperatorDataBase object; //class object created
	object.server(atoi(argv[2]),argv[1]); //server socket function call
	object.serverReadWrite(); //server read and write function call

	return 0;
}
