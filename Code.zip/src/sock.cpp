#include <sock.h>

OperatorDataBase:: OperatorDataBase() //default constructor 
{}
void OperatorDataBase :: server(int ServerPort, string Serverip) //this create server socket
{	  
	 sock=socket(AF_INET,SOCK_STREAM, 0);
	 if(sock < 0)
	 {
		 perror("socket failed");
		 exit(EXIT_FAILURE);
	 }
	 cout<<"-----------------------Socket created----------------------------"<<endl;

	 serveraddr.sin_family = AF_INET;
	 serveraddr.sin_port= htons(ServerPort);
	 serveraddr.sin_addr.s_addr= inet_addr((const char*)Serverip.c_str());

	 binderror=bind(sock, (struct sockaddr*)&serveraddr, sizeof(serveraddr));
	 if(binderror < 0 )
	 {
		 perror("BIND failed");
		 exit(EXIT_FAILURE);
	 }

	 listen(sock , 4); //4: defines the max length for the queue of pending connections.
	 if(listen <0)
	 {
		 perror("Listen failed");
		 exit(EXIT_FAILURE);
	 }

}

void OperatorDataBase::send_file(FILE *fp, int new_socket) //file transfer
{
	char data[SIZE]={0};
	while(fgets(data, SIZE, fp) != NULL)
	{
		if (send(new_socket, data, sizeof(data), 0) == -1) {
			perror("send error");
			exit(EXIT_FAILURE);
		}
		bzero(data,SIZE);
	}
}

void OperatorDataBase :: serverReadWrite() 
{
	while(1)
	{
		new_socket=accept(sock,(struct sockaddr*)&clientaddr,
				(socklen_t*)&client_addr_len);
		if(new_socket < 0)
		{
			perror("Accept failed");
			exit(EXIT_FAILURE);
		}
       if(fork()==0)
       {
		 memset(client_msg, '\0' , sizeof(client_msg));
		 
		 int re=recv(new_socket, client_msg, SIZE, 0);
		 if(re < 0 )
		 {
			 perror("RECV Error");
			 exit(EXIT_FAILURE);
		 }
		 cout<<"recv msg"<<endl;

		 cout<<"User message "<<client_msg<<endl; 
		 memset(server_msg, '\0', sizeof(server_msg));
		 cout<<"Processing in CDR file......."<<endl;

		 processCDRecord(client_msg); 
		
       		 FILE *fp;
		 char *filename="OperatorFile.txt";
	         fp =fopen(filename,"r");
	         send_file(fp, new_socket);
		 fclose(fp);
        }
                close(new_socket);
	}       
	shutdown(sock, SHUT_RDWR); //shutdown to end read/write
}

void OperatorDataBase :: client(int ClientPort , string ClientIP)
{
	 sock_fd=socket(AF_INET, SOCK_STREAM, 0);
	 if(sock_fd < 0)
	 {
		 perror("\n Socket Error ");
		 exit(EXIT_FAILURE);
	 }
	 serveraddr.sin_family= AF_INET;
	 serveraddr.sin_port= htons(ClientPort); 
	 serveraddr.sin_addr.s_addr= inet_addr((const char*)ClientIP.c_str());
	 if(inet_addr < 0)
	 {
		 perror("Invalid address");
		 exit(EXIT_FAILURE);
	 }

	 client_fd=connect(sock_fd, (struct sockaddr*)&serveraddr, sizeof(serveraddr));
	 if(client_fd < 0)
	 {
		 perror("Connection failed");
		 exit(EXIT_FAILURE);
	 }
	 cout<<"---------------------Socket Connection Established ----------------------"<<endl;
}

void OperatorDataBase::write_file(int sock_fd){
	int n;
	FILE *fp;
	char *filename = "recvData.txt";
	char buffer[SIZE];
		 
	fp = fopen(filename, "o");
	while (1) {
		n = recv(sock_fd, buffer, SIZE, 0);
		if (n <= 0){
			break;
			return;
		}
		cout <<(fp , buffer);
		bzero(buffer, SIZE);
	}
}

void OperatorDataBase :: clientReadWrite(int UserInput)
{
	switch(UserInput)
	{
		case 1: 
			cout<<"Enter Brand Name"<<endl;
			cin>>BrandName;
			strcpy(client_msg, (const char*)BrandName.c_str());
		       	//c_str(): converts a string to an array of characters.
			//const char* : pointer to a constant character.
			break;
		case 2:
			cout<<"You want All Brand Details? : Type yes"<<endl;
			cin>> allDetails;
			strcpy(client_msg, (const char*)allDetails.c_str());
			break;
		case 3:
			cout<<"BYE USER"<<endl;
			exit(EXIT_FAILURE);
			break;

		default: 
			cout<<"Invalid Choice"<<endl;
	}

	//send user given input to server from client
       	int clientsend=send(sock_fd,client_msg,strlen(client_msg),0);
	if(clientsend <0)
	{
		perror(" Send eror");
		exit(EXIT_FAILURE);
	}

        //print receive data from server
	write_file(sock_fd);
	

        //socket close
        close(sock_fd);
	
}

OperatorDataBase::~OperatorDataBase() //destructor
{}

