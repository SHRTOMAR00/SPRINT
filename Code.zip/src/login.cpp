#include <sock.h>
bool OperatorDataBase:: loginUser()
{
//	string name,password;
	map<string,string> map1={{"shristi","shri@123"},{"subhiksha","subhi@123"},{"sravani","srav@123"},
		{"leela", "leela@123"},{"shamini", "sham@123"}};
	//store name and password in map
	
	cout<<"--------------------------------*WELCOME*-----------------------------------"<<endl; 
	cout<<"||PLEASE LOGIN||"<<endl;
        cout<<"Enter your Username"<<endl;
	cin>>name;
	cout<<"Enter Password"<<endl;
	cin>>password;

        //condition check with map values to user given values	
	if(map1.find(name)!=map1.end() &&map1[name]==password) 
	{
		cout<<"Login successfully"<<endl;
		return 1;
	}
	else
	{
		cout<<"Invalid login"<<endl;
		return 0;
	}
}
		

