#include <sock.h>
#include <processing.h>

void OperatorDataBase:: processCDRecord(string s)  //s: string enter by user 
{
	fstream operatorfile; //Capabilities of both ofstream and ifstream :create,read,write
	operatorfile.open("OperatorFile.txt" , ios::out); //open file
	
	//streambuf: use to store cout statemnets in file
	//rdbuf(): returns pointer to the internal stream buffer
	streambuf* sb_file = operatorfile.rdbuf();
	cout.rdbuf(sb_file);
	
	long j=0;
	string col[10]; //array for column.
	list<string> mylist; //list
	mylist.push_back(s); //push User given string in list
	list<string> :: iterator it;  //iterator for list
	
	ifstream myfile; //reads cdr file data
	myfile.open("data.cdr"); //open cdr file
	if(myfile)
	{
		cout<<"CDR File Exits"<<endl;
		if( s=="Jio" || s=="Airtel" || s=="Partner" || s=="012" || s=="Cellcom" || s=="yes")
		{
			while(getline(myfile,s)) //take each line upto intermidate s: User string
			{
				stringstream x(s); //allows string object treated as a stream.
				while(getline(x, s ,'|')) //take upto pipe |
				{
					col[j++]=s;
				}
				j=0;

				//stol: converts the string as a argument in function call.
				long value1=stol(col[2]); //col[2]=brandName 
				long value2=stol(col[4]); //col[4]= (call)
				long value3=stol(col[5]); //col[5]= (data upload)
				long value4=stol(col[6]); //col[6]= (data download)
				long value5=0;
				long value6=0;
				long value7=0;
				long value8=1;
				if(map1.count(value1)) 
				{
					if(col[3]=="MTC")
						map1[value1].SetIncomingCall(map1[value1].getIncomingCall()+value2);
					else
						if(col[3]=="MOC")
							map1[value1].SetOutgoingCall(map1[value1].getOutgoingCall()+value2);
						else
							if(col[3]=="GPRS")
							{
								map1[value1].SetDownload(map1[value1].getDownload()+value3);
								map1[value1].SetUpload(map1[value1].getUpload()+value4);
							}
							else
								if(col[3]=="SMS-MT")
									map1[value1].SetIncomingMsg(map1[value1].getIncomingMsg()+1);
								else
									map1[value1].SetOutgoingMsg(map1[value1].getOutgoingMsg()+1);
				}
				else
					if(col[3]=="MTC")
					{
						OperatorDataBase sec(value1,col[1],value2,value7,value3,value4,value5,value6);
						map1[value1]=sec;
					}
					else
						if(col[3]=="MOC")
						{
							OperatorDataBase sec(value1,col[1],value7,value8,value3,value4,value5,value6);
							map1[value1]=sec;
						}
						else
							if(col[3]=="GPRS")
							{
								OperatorDataBase sec(value1,col[1],value7,value8,value3,value4,value5,value6);
								map1[value1]=sec;
							}
							else
								if(col[3]=="SMS-MT")
								{
								OperatorDataBase sec(value1,col[1],value7,value7,value7,value7,value8,value7);
								map1[value1]=sec;
								}
								else
								{
								OperatorDataBase sec(value1,col[1],value7,value7,value7,value7,value7,value8);
								map1[value1]=sec;
								}
			} //while end loop
			
			for(auto itr=map1.begin();itr!=map1.end();++itr)
			{
				for(it=mylist.begin(); it!=mylist.end(); ++it)
				{
					if(itr->second.BrandName==*it) 
					{
						cout<<"Operator Brand Name: "<<itr->second.BrandName <<" (" << itr->first
							<< ")\n\tIncoming voice call durations: " <<(itr->second).getIncomingCall() 
							<<  "\n\tOutgoing voice call durations: " <<(itr->second).getOutgoingCall()
							<< "\n\tIncoming SMS messages: " <<(itr->second).getIncomingMsg()
							<< "\n\tOutgoing SMS messages: "<<(itr->second).getOutgoingMsg()
							<< "\n\tMB downloaded: " <<(itr->second).getDownload()
							<< " | MB uploaded: " <<(itr->second).getUpload() <<endl<<endl;
					}
					else 
						if(*it=="yes")
						{
							cout<<"Operator Brand Name: "<<itr->second.BrandName <<" (" << itr->first
								<< ")\n\tIncoming voice call durations: " <<(itr->second).getIncomingCall()	
								<<  "\n\tOutgoing voice call durations: " <<(itr->second).getOutgoingCall()
								<< "\n\tIncoming SMS messages: " <<(itr->second).getIncomingMsg()
								<< "\n\tOutgoing SMS messages: "<<(itr->second).getOutgoingMsg()
								<< "\n\tMB downloaded: " <<(itr->second).getDownload()
								<< " | MB uploaded: " <<(itr->second).getUpload() <<endl<<endl;
						}
				}
			}		

		}//brand name exits end
		else
		{
			cout<<"Invaild : Not Exits"<<endl;
		}
	} //cdr file exits end 


	else
		cout<<"file doesn't exisit";
	
	mylist.clear(); //clear list memory
        operatorfile.close(); //close OperatorFile.txt

}

//setters
void OperatorDataBase::SetIncomingCall(long incCall)
{
		        incomingCall =incCall;
}
void OperatorDataBase::SetOutgoingCall(long outCall){
		        outgoingCall =outCall;
}
void OperatorDataBase::SetDownload(long download){
		        dataDownload =download;
}
void OperatorDataBase::SetUpload(long upload){
		        dataUpload =upload;
}
void OperatorDataBase::SetIncomingMsg(long incoming){
		        incomingMsg =incoming;
}
void OperatorDataBase::SetOutgoingMsg(long outgoing){
		        outgoingMsg =outgoing;
}

//getters
long OperatorDataBase::getIncomingCall(){
		            return incomingCall;
}
long OperatorDataBase::getOutgoingCall(){
		            return outgoingCall;
}
long OperatorDataBase::getDownload(){
		            return dataDownload;
}
long OperatorDataBase::getUpload(){
		            return dataUpload;
}
long OperatorDataBase::getIncomingMsg(){
		            return incomingMsg;
}
long OperatorDataBase::getOutgoingMsg(){
		            return outgoingMsg;
}
long OperatorDataBase::getBrandName(){
		            return BrandOperators;
}
