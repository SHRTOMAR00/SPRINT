#include <sock.h>

int main(int argc, char*argv[])
{
	OperatorDataBase object1; //class object created
        if(object1.loginUser()==1) //check user login condition
	{
		while(1) //while loop for iterative conditions
		{
		int choice;
		cout<<"Enter your choice"<<endl
			<<"1. Search By Brand Name"<<endl
			<<"2. Search all Brand Details"<<endl
			<<"3. Exit"<<endl;
		cin>>choice;
		
		object1.client(atoi(argv[2]), argv[1]); //client socket create function call
		object1.clientReadWrite(choice); //client read and write function call
		}
	}
	else {
		cout<<"Sorry..try again"<<endl;
	}
	return 0;
}
