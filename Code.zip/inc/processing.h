#include <fstream>
#include <iostream>
#include <string>
#include <list>
#include <iterator>
#include <bits/stdc++.h>
#include <map>
#include <ostream>
using namespace std;


