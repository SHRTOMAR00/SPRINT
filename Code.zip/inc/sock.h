#pragma once
#include        <iostream>
#include        <stdlib.h>
#include        <errno.h>
#include        <fstream>
#include        <string.h>
#include        <sys/types.h>
#include        <sys/socket.h>
#include        <netinet/in.h>
#include        <arpa/inet.h>
#include        <sys/wait.h>
#include        <fcntl.h>
#include        <unistd.h>
#include        <bits/stdc++.h>
#include        <stdarg.h>
#include        <iterator>
#include        <string>
#include        <cstring>
#define         SIZE         1024
using namespace std;

class OperatorDataBase
{
	private:
		//Data Members 

		//use in server side
		int sock;
		int new_socket;
		int binderror;

                //use in client side
		int sock_fd;
		int client_fd;

		struct sockaddr_in serveraddr , clientaddr;
		char server_msg[SIZE];
		char client_msg[SIZE];
		int server_addr_len = sizeof(serveraddr);		
		int client_addr_len = sizeof(clientaddr);
                
		long BrandOperators;
                string BrandName;
		string name,password;
		string allDetails;
	        long incomingCall;
	        long outgoingCall;
		long dataDownload;
		long dataUpload;
		long incomingMsg;
		long outgoingMsg;
	public:
		//Member function 

                OperatorDataBase(); //default constructor
		OperatorDataBase(long o ,string b, long incCall, long outCall,long down, long up, long in, long out) //parameterized constructor
		{
			BrandOperators=o;
	    		BrandName =b;
			incomingCall=incCall;
			outgoingCall=outCall;
			dataDownload=down;
			dataUpload=up;
			incomingMsg=in;
			outgoingMsg=out;
		}

		bool loginUser(); //user login condition
		void server(int, string);  //server socket create function
		void serverReadWrite(); //server  sendto(), recvfrom() function
		void client(int , string);  //client socket create function
		void clientReadWrite(int); //client sendto(), recvfrom() function
		void processCDRecord(string); //all logic of CDR , STL  
		map <long, OperatorDataBase> map1; //use for storing & processing CDR file
	        void send_file(FILE* , int );
		void write_file(int);
	        void SetOutgoingCall(long);
		void SetIncomingCall(long);
		void SetDownload(long);
		void SetUpload(long);
		void SetIncomingMsg(long);
		void SetOutgoingMsg(long );
		long getIncomingCall();
		long getOutgoingCall();
		long getDownload();
		long getUpload();
		long getIncomingMsg();
		long getOutgoingMsg();
		long getBrandName();
		~OperatorDataBase(); //destructor

} ;
